# Retroserv 0.1.2 — Fedora Linux SNES ROM Inspection & Preservation

**Linux-first, aimed at the Fedora family:** Fedora Workstation, Fedora KDE Plasma
Desktop, Fedora Spins, and Fedora Atomic desktops (Bazzite, Silverblue, Kinoite).

Retroserv is an MIT-licensed, source-available Python ROM inspection utility.
It can read SNES ROMs, decode *uncompressed* graphics and palettes at specified
addresses, generate PNG exports with provenance, scan ASCII, and inspect hex.
**It is not a universal SNES game decompiler or a finished game builder.**

## Getting started on a Fedora laptop (Workstation/KDE/Spin)

1. Extract the ZIP or tarball to `~/Retroserv` (any directory under home works).
2. Open a terminal in that folder and run:

```bash
chmod +x ./*.sh scripts/*.sh
./Setup-Fedora.sh --check          # see what the installer will use
./Setup-Fedora.sh                  # on standard Fedora, native install
./Start-Retroserv.sh
```

On standard Fedora this uses `python3`, a **project-local virtual environment**
(`.venv`), and pip. If system Tk/pip are missing it invokes `sudo dnf install -y
python3 python3-pip python3-tkinter` to install the required distro packages.
If those prerequisites are already available, no sudo is needed. The first
install requires internet access for Python packages (Pillow and pytest).

**Do not use `sudo pip` or enable `--break-system-packages`.**

## Bazzite / Silverblue / Kinoite (Fedora Atomic)

The same `./Setup-Fedora.sh` detects `/run/ostree-booted` (or `/run/bootc-booted`)
and selects **Distrobox** instead of layering RPMs on the immutable host.
It requires Distrobox and Podman already installed on the host. If missing,
consult your distribution's Distrobox documentation; setup stops with an error.
It creates/uses container `retroserv-dev` from `registry.fedoraproject.org/fedora-toolbox:44`,
installs Python/pip/Tk there, and installs Retroserv to `.venv-distrobox`
under the project directory.

```bash
./Setup-Fedora.sh --check
./Setup-Fedora.sh
./Start-Retroserv.sh
```

The old `Setup-Bazzite.sh` remains as a compatibility alias which explicitly
selects Distrobox; new users should run `Setup-Fedora.sh`.

### Choosing a mode manually

On Fedora Workstation, the default is **native**. To opt into Distrobox:

```bash
RETROSERV_MODE=distrobox ./Setup-Fedora.sh
```

Or force a native install if you already have a working host Python+Tk setup:

```bash
RETROSERV_MODE=native ./Setup-Fedora.sh
```

Successful setup records your choice in `.retroserv-install-mode` (ignored by
Git and excluded from the release archive); launchers then use that mode.
`RETROSERV_MODE=native|distrobox` can also override the saved choice for a
single launch. Use separate virtual environments to avoid Python ABI conflicts.

## Verify using the included original test ROM

The included `samples/retroserv_test.sfc` is **synthetic nonplayable data**.
Launch the GUI and open it. In Tile / Palette Viewer:

| Setting | Value |
| --- | --- |
| Tile offset | `0x12000` |
| Bits per pixel | `4` |
| Tile count | `64` |
| Columns | `8` |
| Palette offset | `0x13000` |

Click Preview tiles, then try PNG export. None of these operations modifies
source ROMs.

CLI tests after setup:

```bash
./Retroserv-CLI.sh --version
./Retroserv-CLI.sh inspect samples/retroserv_test.sfc
./Retroserv-CLI.sh scan samples/retroserv_test.sfc --bpp 4 --limit 10
./Retroserv-CLI.sh tiles samples/retroserv_test.sfc --offset 0x12000 --bpp 4 --count 64 --columns 8 --palette-offset 0x13000 --output /tmp/retroserv-tiles.png
```

## Cursor MCP

Run `./Install-MCP.sh`. Copy the full absolute path of
`Run-Retroserv-MCP.sh` into the `command` entry of your Cursor MCP
configuration. More at `docs/CURSOR_MCP.md`.
The MCP server uses the official MCP Python SDK v2; a Cursor handshake on
actual Fedora hardware **has not yet been tested**.

## Supported capabilities

- Read `.sfc` and `.smc` ROMs; identify possible LoROM/HiROM/ExHiROM headers.
- Handle optional 512-byte copier headers and record SHA-256 fingerprints.
- Hex view and export byte ranges without modifying original files.
- Decode 2bpp, 4bpp, 8bpp planar tiles and BGR555 palettes at given offsets.
- Rank potential graphics offsets heuristically; **not automatic asset identification**.
- Find printable ASCII runs; **not generic dialogue/script extraction**.
- GUI, CLI, and optional MCP server.

**Missing:** proprietary compression algorithms, game-specific dialogue,
accurate maps and animations, 65816 disassembly/decompilation, automated asset
identification, and building playable SNES cartridges. Other open-source tools
are listed in `docs/OPEN_SOURCE.md` but have not been integrated.

## Testing limits

Automated checks and headless GUI tests were run in an isolated Linux
container, not on an actual Fedora laptop, Silverblue, or Bazzite system.
The Fedora host package manager and Podman/Distrobox workflows still require
real-world verification. See `TEST_RESULTS_FEDORA.txt`.

Only analyze copies of ROMs you have the right to possess and work with.
Exporting data does not authorize distributing another game's copyrighted
assets or code.
