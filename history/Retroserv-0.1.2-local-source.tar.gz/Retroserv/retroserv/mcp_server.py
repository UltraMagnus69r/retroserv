"""Optional local MCP stdio server (requires mcp>=2,<3).

For security, this server is local-only and does not accept network connections.
The tools remain read-only on source ROMs, writing only explicit user exports.
"""
from __future__ import annotations
from .rom import RomImage, parse_offset
from .graphics import scan_graphics
from .textscan import scan_ascii
from .export import graphics_export, binary_export

try:
    from mcp.server import MCPServer
except ImportError as exc:
    raise SystemExit('Install MCP integration: python -m pip install -e ".[mcp]"') from exc

mcp = MCPServer('Retroserv')


@mcp.tool()
def inspect_rom(rom_path: str) -> dict:
    """Inspect and SHA256-hash a local SNES ROM without modifying it."""
    return RomImage(rom_path).info()


@mcp.tool()
def find_graphics_candidates(rom_path: str, bpp: int = 4, limit: int = 20) -> dict:
    """Rank raw potential tile regions. Heuristic: NOT verified graphics or sprites."""
    rom = RomImage(rom_path)
    return {'candidates':[c.to_dict() for c in scan_graphics(rom.data, bpp=bpp, limit=limit)],
            'warning':'Candidate offsets can refer to code, compressed data, or noise.'}


@mcp.tool()
def find_ascii_strings(rom_path: str, min_length: int = 8, contains: str = '', limit: int = 200) -> dict:
    """Find ASCII strings; cannot decode arbitrary custom SNES script encodings."""
    rom = RomImage(rom_path)
    return {'findings':[r.to_dict() for r in scan_ascii(rom.data, min_length, limit, contains)],
            'warning':'Printable runs are not confirmed dialogue scripts.'}


@mcp.tool()
def export_graphics(rom_path: str, output_png: str, offset: str,
                    bpp: int = 4, count: int = 128, columns: int = 16,
                    palette_offset: str = '', transparent_zero: bool = False) -> dict:
    """Export raw 2/4/8bpp tile pixels to PNG with provenance JSON; never overwrites."""
    rom = RomImage(rom_path)
    p = parse_offset(palette_offset) if palette_offset.strip() else None
    return graphics_export(rom, output_png, parse_offset(offset), bpp, count,
                           columns, p, transparent_zero)


@mcp.tool()
def export_raw_region(rom_path: str, output_file: str, offset: str, length: int) -> dict:
    """Copy a ROM byte region and provenance sidecar; never overwrites."""
    return binary_export(RomImage(rom_path), output_file, parse_offset(offset), length)

if __name__ == '__main__':
    mcp.run(transport='stdio')
