"""Retroserv: preservation-oriented, read-only analysis of SNES ROM images."""
__version__ = "0.1.2"
