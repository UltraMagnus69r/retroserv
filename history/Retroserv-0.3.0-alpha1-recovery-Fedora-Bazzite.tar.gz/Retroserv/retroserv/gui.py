"""Cross-platform Tk desktop ROM inspector; Fedora Linux is the primary target."""
from __future__ import annotations
import json
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from PIL import Image, ImageTk
from . import __version__
from .palettes import ImportedPalette, load_palette
from .rom import RomImage, parse_offset
from .graphics import read_palette, render_tiles, scan_graphics
from .textscan import scan_ascii, hex_dump
from .export import graphics_export, binary_export
from .smw import list_gfx, decoded_gfx, gfx_preview, export_gfx, recognized, GFX_GROUPS
from .desktop_paths import default_rom_directory


class RetroservGUI(tk.Tk):
    def __init__(self):
        super().__init__(className='Retroserv')
        self.title(f'Retroserv {__version__} — SNES Preservation Workbench')
        self.window_icon = tk.PhotoImage(file=Path(__file__).with_name('retroserv.png'))
        self.iconphoto(True, self.window_icon)
        self.geometry('1130x800')
        self.minsize(850, 580)
        self.rom: RomImage | None = None
        self.preview_photo = None
        self.smw_preview_photo = None
        self.offset = tk.StringVar(value='0x12000')
        self.bpp = tk.StringVar(value='4')
        self.count = tk.StringVar(value='128')
        self.columns = tk.StringVar(value='16')
        self.palette_offset = tk.StringVar(value='')
        self.transparency = tk.BooleanVar(value=False)
        self.zoom = tk.StringVar(value='4')
        self.smw_zoom = tk.StringVar(value='4')
        self.smw_palette: ImportedPalette | None = None
        self.smw_palette_name = tk.StringVar(value='Grayscale')
        self.smw_palette_start = tk.StringVar(value='0')
        self.min_ascii = tk.StringVar(value='8')
        self.contains = tk.StringVar(value='')
        self.hex_offset = tk.StringVar(value='0x0')
        self.hex_length = tk.StringVar(value='256')

        self.ui_font = 'DejaVu Sans' if sys.platform.startswith('linux') else 'Segoe UI'
        self.mono_font = 'DejaVu Sans Mono' if sys.platform.startswith('linux') else 'Consolas'
        self.configure(background='#181e26')
        style = ttk.Style(self)
        if 'clam' in style.theme_names():
            style.theme_use('clam')
        style.configure('TNotebook', background='#212936', borderwidth=0)
        style.configure('TNotebook.Tab', padding=(16, 9), font=(self.ui_font, 10))
        style.configure('TButton', padding=(9, 6))
        style.configure('TLabel', font=(self.ui_font, 10))
        style.configure('Header.TLabel', font=(self.ui_font, 13, 'bold'))
        style.configure('Treeview', rowheight=25)
        self._make_menu()
        toolbar = ttk.Frame(self, padding=(14, 10))
        toolbar.pack(fill='x')
        ttk.Label(toolbar, text='RETROSERV', style='Header.TLabel').pack(side='left')
        ttk.Button(toolbar, text='Open ROM…', command=self.open_rom).pack(side='left', padx=16)
        self.file_label = ttk.Label(toolbar, text='No ROM loaded — open a .sfc or .smc file')
        self.file_label.pack(side='left', padx=4)
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill='both', expand=True, padx=12, pady=(2,8))
        self.tab_info, self.tab_gfx, self.tab_smw, self.tab_text, self.tab_hex = [ttk.Frame(self.notebook) for _ in range(5)]
        for tab, name in [(self.tab_info,'ROM Inspector'), (self.tab_gfx,'Tile / Palette Viewer'),
                          (self.tab_smw,'SMW Graphics'),
                          (self.tab_text,'ASCII Finder'), (self.tab_hex,'Hex Viewer')]:
            self.notebook.add(tab, text=name)
        self._info_tab()
        self._graphics_tab()
        self._smw_tab()
        self._text_tab()
        self._hex_tab()
        self.status = tk.StringVar(value='Ready. The original ROM is never edited.')
        ttk.Label(self, textvariable=self.status, padding=(12,6)).pack(fill='x')

    def _make_menu(self):
        menu = tk.Menu(self)
        file_menu = tk.Menu(menu, tearoff=False)
        file_menu.add_command(label='Open ROM…', command=self.open_rom)
        file_menu.add_command(label='Export inspection JSON…', command=self.export_info)
        file_menu.add_separator()
        file_menu.add_command(label='Exit', command=self.destroy)
        menu.add_cascade(label='File', menu=file_menu)
        self.config(menu=menu)

    def _info_tab(self):
        ttk.Label(self.tab_info, text='Read-only ROM fingerprint and cartridge header',
                  style='Header.TLabel').pack(anchor='w', padx=12, pady=12)
        self.info_text = tk.Text(self.tab_info, wrap='none', font=(self.mono_font, 10), borderwidth=0,
                                 background='#111821', foreground='#d9e2eb', insertbackground='#d9e2eb')
        self.info_text.pack(fill='both', expand=True, padx=12, pady=(0,12))
        self.info_text.insert('1.0', 'Open a ROM to inspect internal headers, hashes, and source size.\n\n'
                              'Header detection is heuristic; uncertain candidates are marked.')
        self.info_text.configure(state='disabled')

    def _graphics_tab(self):
        top = ttk.Frame(self.tab_gfx, padding=10)
        top.pack(fill='x')
        values = [("Data offset", self.offset, 12), ("BPP", self.bpp, 4),
                  ("Tiles", self.count, 7), ("Columns", self.columns, 6),
                  ("Palette offset", self.palette_offset, 12), ("Zoom", self.zoom, 4)]
        for title, var, width in values:
            group = ttk.Frame(top)
            group.pack(side='left', padx=(0,12))
            ttk.Label(group, text=title).pack(anchor='w')
            if title in ('BPP','Zoom'):
                values_option = ('2','3','4','8') if title == 'BPP' else ('1','2','3','4','5','6')
                ttk.Combobox(group, width=width, textvariable=var, values=values_option,
                             state='readonly').pack()
            else:
                ttk.Entry(group, width=width, textvariable=var).pack()
        actions = ttk.Frame(self.tab_gfx, padding=(10,1))
        actions.pack(fill='x')
        ttk.Checkbutton(actions, text='Transparent index 0', variable=self.transparency).pack(side='left', padx=(0,12))
        ttk.Button(actions, text='Preview tiles', command=self.preview).pack(side='left', padx=5)
        ttk.Button(actions, text='Export PNG + provenance…', command=self.export_tiles).pack(side='left', padx=5)
        ttk.Button(actions, text='Scan candidate offsets', command=self.scan_candidates).pack(side='left', padx=5)
        ttk.Label(self.tab_gfx, text='All ROM offsets are data-relative. Scanned offsets are guesses, not verified sprite locations.',
                  foreground='#93500a').pack(anchor='w', padx=10, pady=4)
        splitter = ttk.Panedwindow(self.tab_gfx, orient='horizontal')
        splitter.pack(fill='both', expand=True, padx=10, pady=(0,10))
        left = ttk.Frame(splitter)
        right = ttk.Frame(splitter, width=235)
        splitter.add(left, weight=4)
        splitter.add(right, weight=1)
        self.canvas = tk.Canvas(left, background='#1b212b', highlightthickness=0)
        self.cv_x = ttk.Scrollbar(left, orient='horizontal', command=self.canvas.xview)
        self.cv_y = ttk.Scrollbar(left, orient='vertical', command=self.canvas.yview)
        self.canvas.configure(xscrollcommand=self.cv_x.set, yscrollcommand=self.cv_y.set)
        self.canvas.grid(row=0,column=0,sticky='nsew')
        self.cv_x.grid(row=1,column=0,sticky='ew')
        self.cv_y.grid(row=0,column=1,sticky='ns')
        left.grid_rowconfigure(0,weight=1)
        left.grid_columnconfigure(0,weight=1)
        ttk.Label(right, text='Candidate regions', style='Header.TLabel').pack(anchor='w', pady=7)
        ttk.Label(right, text='Double-click to preview\n(heuristic guesses only)').pack(anchor='w', pady=(0,4))
        self.candidates = tk.Listbox(right, font=(self.mono_font,10), activestyle='dotbox')
        self.candidates.pack(fill='both', expand=True)
        self.candidates.bind('<Double-Button-1>', self._open_candidate)

    def _smw_tab(self):
        bar = ttk.Frame(self.tab_smw, padding=10)
        bar.pack(fill='x')
        ttk.Label(bar, text='Super Mario World USA v1.0 — exact SHA-256 profile',
                  style='Header.TLabel').pack(side='left', padx=(0, 14))
        ttk.Button(bar, text='Discover GFX', command=self.smw_discover).pack(side='left', padx=4)
        ttk.Button(bar, text='Preview', command=self.smw_preview).pack(side='left', padx=4)
        ttk.Button(bar, text='Export selected…', command=self.smw_export_one).pack(side='left', padx=4)
        ttk.Button(bar, text='Export all…', command=self.smw_export_all).pack(side='left', padx=4)
        controls = ttk.Frame(self.tab_smw, padding=(10, 0))
        controls.pack(fill='x')
        ttk.Button(controls, text='Load .pal / CGRAM…', command=self.smw_load_palette).pack(side='left')
        ttk.Button(controls, text='Grayscale', command=self.smw_clear_palette).pack(side='left', padx=5)
        ttk.Label(controls, text='Start color').pack(side='left', padx=(10, 4))
        start = ttk.Entry(controls, width=6, textvariable=self.smw_palette_start)
        start.pack(side='left')
        start.bind('<Return>', self.smw_refresh_preview)
        ttk.Label(controls, text='Zoom').pack(side='left', padx=(10, 4))
        zoom = ttk.Combobox(controls, width=4, textvariable=self.smw_zoom,
                            values=('1', '2', '3', '4', '5', '6'), state='readonly')
        zoom.pack(side='left')
        zoom.bind('<<ComboboxSelected>>', self.smw_refresh_preview)
        ttk.Label(controls, textvariable=self.smw_palette_name, width=26).pack(side='left', padx=10)
        ttk.Label(self.tab_smw,
                  text='Choose a starting color for the imported palette. GFX27 exports as raw data.', foreground='#93500a').pack(anchor='w', padx=10, pady=4)
        pane = ttk.Panedwindow(self.tab_smw, orient='horizontal')
        pane.pack(fill='both', expand=True, padx=10, pady=8)
        left, right = ttk.Frame(pane), ttk.Frame(pane)
        pane.add(left, weight=2)
        pane.add(right, weight=3)
        self.smw_tree = ttk.Treeview(left, columns=('name','offset','bpp','note'), show='headings', height=25)
        for col, label, width in [('name','GFX',75),('offset','ROM offset',110),('bpp','BPP',45),('note','Graphics group',230)]:
            self.smw_tree.heading(col, text=label)
            self.smw_tree.column(col, width=width, stretch=(col == 'note'))
        self.smw_tree.pack(fill='both', expand=True)
        self.smw_tree.bind('<Double-Button-1>', lambda _: self.smw_preview())
        self.smw_canvas = tk.Canvas(right, background='#1b212b', highlightthickness=0)
        scroll_y = ttk.Scrollbar(right, orient='vertical', command=self.smw_canvas.yview)
        scroll_x = ttk.Scrollbar(right, orient='horizontal', command=self.smw_canvas.xview)
        self.smw_canvas.configure(xscrollcommand=scroll_x.set, yscrollcommand=scroll_y.set)
        self.smw_canvas.grid(row=0, column=0, sticky='nsew')
        scroll_y.grid(row=0, column=1, sticky='ns')
        scroll_x.grid(row=1, column=0, sticky='ew')
        right.grid_rowconfigure(0, weight=1)
        right.grid_columnconfigure(0, weight=1)

    def smw_discover(self):
        def do():
            rom = self._require_rom()
            entries = list_gfx(rom)
            for item in self.smw_tree.get_children():
                self.smw_tree.delete(item)
            for entry in entries:
                self.smw_tree.insert('', 'end', iid=str(entry.number),
                    values=(f'GFX{entry.number:02X}', f'0x{entry.data_offset:05X}',
                            entry.bpp if entry.bpp else 'Mode7', GFX_GROUPS[entry.number]))
            self.status.set(f'{len(entries)} documented SMW GFX pointers found; content not yet validated')
        self._handle(do)

    def _smw_selected(self):
        picked = self.smw_tree.selection()
        if not picked:
            raise ValueError('Click Discover GFX and select a graphics entry')
        return int(picked[0])

    def smw_refresh_preview(self, _event=None):
        if self.smw_tree.selection():
            self.smw_preview()

    def smw_load_palette(self):
        filename = filedialog.askopenfilename(title='Load SNES palette',
                       filetypes=[('Palette dumps', '*.pal *.cgram *.bin *.dmp'), ('All files', '*.*')])
        if not filename:
            return

        def do():
            self.smw_palette = load_palette(filename)
            self.smw_palette_name.set(self.smw_palette.name)
            self.smw_palette_start.set('0')
            self.smw_refresh_preview()
        self._handle(do)

    def smw_clear_palette(self):
        self.smw_palette = None
        self.smw_palette_name.set('Grayscale')
        self.smw_palette_start.set('0')
        self.smw_refresh_preview()

    def smw_palette_index(self):
        return parse_offset(self.smw_palette_start.get()) if self.smw_palette is not None else 0

    def smw_preview(self):
        def do():
            entry, result = decoded_gfx(self._require_rom(), self._smw_selected())
            start = self.smw_palette_index()
            image = gfx_preview(entry, result, palette=self.smw_palette, palette_start=start)
            zoom = int(self.smw_zoom.get())
            enlarged = image.resize((image.width * zoom, image.height * zoom), Image.Resampling.NEAREST)
            self.smw_preview_photo = ImageTk.PhotoImage(enlarged)
            self.smw_canvas.delete('all')
            self.smw_canvas.create_image(0, 0, anchor='nw', image=self.smw_preview_photo)
            self.smw_canvas.configure(scrollregion=(0, 0, enlarged.width, enlarged.height))
            colors = f'{self.smw_palette.format} from color {start}' if self.smw_palette else 'Grayscale'
            self.status.set(f'GFX{entry.number:02X} • {len(result.data)} decoded bytes • {colors} • {zoom}×')
        self._handle(do)

    def smw_export_one(self):
        def do():
            rom = self._require_rom()
            number = self._smw_selected()
            folder = filedialog.askdirectory(title='Choose directory for SMW GFX export')
            if not folder: return
            result = export_gfx(rom, number, folder, palette=self.smw_palette,
                                palette_start=self.smw_palette_index())
            self.status.set(f'Exported {result["name"]} with provenance: {folder}')
            messagebox.showinfo('Retroserv', f'Exported {result["name"]} to {folder}')
        self._handle(do)

    def smw_export_all(self):
        def do():
            rom = self._require_rom()
            if not recognized(rom):
                raise ValueError('Exact SMW USA v1.0 ROM fingerprint required')
            folder = filedialog.askdirectory(title='Choose empty output folder for all GFX')
            if not folder: return
            output = Path(folder)
            # Avoid accidental overwrite, and warn before generating many files.
            if any(output.glob('GFX*')):
                raise ValueError('Output contains GFX files; choose an empty output directory')
            start = self.smw_palette_index()
            if self.smw_palette:
                self.smw_palette.group(start, 3)
            if not messagebox.askyesno('Retroserv', 'Export 50 GFX entries to this folder?', parent=self):
                return
            successes, failures = 0, []
            for number in range(0x32):
                try:
                    export_gfx(rom, number, output, palette=self.smw_palette, palette_start=start)
                    successes += 1
                except (ValueError, OSError) as exc:
                    failures.append(f'GFX{number:02X}: {exc}')
            self.status.set(f'Exported {successes}/50 SMW GFX entries; {len(failures)} failures')
            messagebox.showinfo('Retroserv', f'Exported {successes}/50 GFX entries. '
                    + ('Errors: '+ '; '.join(failures[:5]) if failures else 'No errors.'), parent=self)
        self._handle(do)

    def _text_tab(self):
        bar = ttk.Frame(self.tab_text, padding=10)
        bar.pack(fill='x')
        ttk.Label(bar, text='Min length').pack(side='left')
        ttk.Entry(bar, textvariable=self.min_ascii, width=6).pack(side='left', padx=8)
        ttk.Label(bar, text='Contains').pack(side='left')
        ttk.Entry(bar, textvariable=self.contains, width=32).pack(side='left', padx=8)
        ttk.Button(bar, text='Find ASCII runs', command=self.find_strings).pack(side='left')
        ttk.Label(self.tab_text, text='These are printable byte sequences, not decoded dialogue or verified scripts.',
                  foreground='#93500a').pack(anchor='w', padx=10, pady=6)
        columns = ('offset','text')
        self.string_tree = ttk.Treeview(self.tab_text, columns=columns, show='headings')
        self.string_tree.heading('offset', text='ROM data offset')
        self.string_tree.heading('text', text='ASCII text')
        self.string_tree.column('offset', width=160, stretch=False)
        self.string_tree.column('text', width=700)
        self.string_tree.pack(fill='both', expand=True, padx=10,pady=8)
        self.string_tree.bind('<Double-Button-1>', self._string_hex_jump)

    def _hex_tab(self):
        bar = ttk.Frame(self.tab_hex, padding=10)
        bar.pack(fill='x')
        ttk.Label(bar, text='Data offset').pack(side='left')
        ttk.Entry(bar, textvariable=self.hex_offset, width=16).pack(side='left', padx=8)
        ttk.Label(bar, text='Length (1–65536)').pack(side='left')
        ttk.Entry(bar, textvariable=self.hex_length, width=12).pack(side='left', padx=8)
        ttk.Button(bar, text='View bytes', command=self.show_hex).pack(side='left', padx=6)
        ttk.Button(bar, text='Export raw slice…', command=self.export_slice).pack(side='left')
        self.hex_text = tk.Text(self.tab_hex, wrap='none', font=(self.mono_font,11), background='#111821',
                                foreground='#d9e2eb', insertbackground='#d9e2eb', borderwidth=0)
        self.hex_text.pack(fill='both', expand=True, padx=10,pady=8)

    def _require_rom(self):
        if self.rom is None:
            raise ValueError('Open a ROM before using this action')
        return self.rom

    def _handle(self, action):
        try:
            return action()
        except (OSError, ValueError, RuntimeError) as exc:
            messagebox.showerror('Retroserv', str(exc), parent=self)
            self.status.set(f'Error: {exc}')
            return None

    def open_rom(self):
        filename = filedialog.askopenfilename(title='Select SNES ROM',
                     initialdir=str(default_rom_directory()),
                     filetypes=[('SNES ROM images','*.sfc *.smc *.fig *.bin'),('All files','*.*')])
        if not filename: return
        def do():
            self.rom = RomImage(filename)
            info = self.rom.info()
            self.file_label.configure(text=f'{Path(filename).name}  •  {len(self.rom.data):,} data bytes')
            self.info_text.configure(state='normal')
            self.info_text.delete('1.0','end')
            self.info_text.insert('1.0', json.dumps(info, indent=2))
            self.info_text.configure(state='disabled')
            self.candidates.delete(0,'end')
            for item in self.string_tree.get_children(): self.string_tree.delete(item)
            self.canvas.delete('all')
            self.preview_photo = None
            for item in self.smw_tree.get_children(): self.smw_tree.delete(item)
            self.smw_canvas.delete('all')
            self.smw_preview_photo = None
            self.status.set(f'Loaded {Path(filename).name} (READ ONLY)')
            self.notebook.select(self.tab_info)
        self._handle(do)

    def export_info(self):
        if self.rom is None:
            messagebox.showinfo('Retroserv', 'Open a ROM first')
            return
        name = filedialog.asksaveasfilename(title='Save inspection JSON',
                          defaultextension='.json', filetypes=[('JSON','*.json')])
        if not name: return
        def do():
            from .export import save_json
            save_json(Path(name), self.rom.info())
            self.status.set(f'Inspection saved: {name}')
        self._handle(do)

    def _graphics_parameters(self):
        rom = self._require_rom()
        off = parse_offset(self.offset.get())
        bpp, count, columns = int(self.bpp.get()), int(self.count.get()), int(self.columns.get())
        pal = parse_offset(self.palette_offset.get()) if self.palette_offset.get().strip() else None
        return rom, off, bpp, count, columns, pal

    def preview(self):
        def do():
            rom, off, bpp, count, columns, pal = self._graphics_parameters()
            colors = read_palette(rom.slice(pal, 2*(1<<bpp)),1<<bpp) if pal is not None else None
            bitmap = render_tiles(rom.data,off,bpp,count,columns,colors,self.transparency.get())
            mult = int(self.zoom.get())
            resized = bitmap.resize((bitmap.width*mult,bitmap.height*mult),resample=0)
            self.preview_photo = ImageTk.PhotoImage(resized)
            self.canvas.delete('all')
            self.canvas.create_image(0,0,anchor='nw',image=self.preview_photo)
            self.canvas.configure(scrollregion=(0,0,resized.width,resized.height))
            self.status.set(f'Preview: 0x{off:X}, {bpp}bpp, {count} tiles, {bitmap.width}×{bitmap.height} logical pixels')
        self._handle(do)

    def export_tiles(self):
        if self.rom is None:
            self._handle(self._require_rom); return
        filename = filedialog.asksaveasfilename(title='Export decoded PNG', defaultextension='.png',
                      filetypes=[('PNG image','*.png')])
        if not filename: return
        def do():
            rom, off, bpp, count, columns, pal = self._graphics_parameters()
            result = graphics_export(rom,filename,off,bpp,count,columns,pal,self.transparency.get())
            self.status.set(f"PNG saved with provenance: {result['png']}")
            messagebox.showinfo('Retroserv',f"Saved PNG and provenance JSON:\n{result['png']}\n{result['sidecar']}")
        self._handle(do)

    def scan_candidates(self):
        def do():
            rom = self._require_rom()
            self.status.set('Scanning ROM for plausible tile patterns…')
            self.update_idletasks()
            rows = scan_graphics(rom.data, int(self.bpp.get()), limit=40)
            self._candidate_rows = rows
            self.candidates.delete(0,'end')
            for candidate in rows:
                self.candidates.insert('end',f'0x{candidate.offset:06X}  score {candidate.score:.2f}')
            self.status.set(f'Ranked {len(rows)} heuristic candidates. No asset identities verified.')
        self._handle(do)

    def _open_candidate(self,_event):
        sel = self.candidates.curselection()
        if sel and getattr(self,'_candidate_rows',None):
            self.offset.set(f'0x{self._candidate_rows[sel[0]].offset:X}')
            self.preview()

    def find_strings(self):
        def do():
            rom = self._require_rom()
            rows = scan_ascii(rom.data,int(self.min_ascii.get()),2000,self.contains.get())
            for item in self.string_tree.get_children(): self.string_tree.delete(item)
            for row in rows:
                self.string_tree.insert('', 'end',values=(f'0x{row.offset:06X}',row.text[:500]))
            self.status.set(f'{len(rows)} printable ASCII runs (max 2,000); game-specific encodings not decoded')
        self._handle(do)

    def _string_hex_jump(self,_event):
        selected = self.string_tree.selection()
        if selected:
            self.hex_offset.set(self.string_tree.item(selected[0], 'values')[0])
            self.notebook.select(self.tab_hex)
            self.show_hex()

    def show_hex(self):
        def do():
            rom = self._require_rom()
            result = hex_dump(rom.data,parse_offset(self.hex_offset.get()),int(self.hex_length.get()))
            self.hex_text.delete('1.0','end')
            self.hex_text.insert('1.0',result)
            self.status.set('Hexadecimal ROM data viewer (read only)')
        self._handle(do)

    def export_slice(self):
        if self.rom is None: self._handle(self._require_rom); return
        filename = filedialog.asksaveasfilename(title='Export raw bytes', defaultextension='.bin',
                                                 filetypes=[('Binary','*.bin'),('All files','*.*')])
        if not filename: return
        def do():
            result = binary_export(self.rom,filename,parse_offset(self.hex_offset.get()),
                                   parse_offset(self.hex_length.get()))
            self.status.set(f"Copied bytes with provenance: {result['binary']}")
        self._handle(do)


def launch():
    app = RetroservGUI()
    app.mainloop()

if __name__ == '__main__':
    launch()
